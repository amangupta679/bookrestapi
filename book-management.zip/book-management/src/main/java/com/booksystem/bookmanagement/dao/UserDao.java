package com.booksystem.bookmanagement.dao;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;

import com.booksystem.bookmanagement.pojo.Users;



public interface UserDao extends JpaRepository<Users, Integer>  {
	
	
	@Query(nativeQuery = true,value = "select * from user where username=:username")
	Users getUserByUserName(@Param("username")String username);

}
