package com.booksystem.bookmanagement.service;

import java.util.Map;


import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Service;



@Service
public interface UserService {
	
	ResponseEntity<String> signUp(Map<String , String> requestMap ) ; 
	
	public ResponseEntity<String> updateProfile(Map<String,String>map);
}
