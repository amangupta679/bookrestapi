package com.booksystem.bookmanagement.serviceimpl;

import java.text.SimpleDateFormat;
import java.time.LocalDateTime;
import java.time.format.DateTimeFormatter;
import java.util.Date;
import java.util.Map;
import java.util.Objects;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;

import com.booksystem.bookmanagement.dao.UserDao;
import com.booksystem.bookmanagement.pojo.Users;

public class UserServiceImpl {

	@Autowired
	private UserDao userDao ; 
	
	
	public  ResponseEntity<String> signUp(Map<String , String> requestMap){
		try {
			System.out.println(requestMap.toString());
			Users users = userDao.getUserByUserName(requestMap.get("username")) ; 
			
			if(Objects.isNull(users)) {
				userDao.save(configUser(requestMap));
				return new ResponseEntity<String>("USER ADDED",HttpStatus.OK);
			}
			else {
				return new ResponseEntity<String>("USERNAME ALREADY TAKEN",HttpStatus.OK);
			}
		}
		catch (Exception e) {
			e.printStackTrace();
		}
		return new ResponseEntity<String>("SOMETHING WENT WRONG",HttpStatus.INTERNAL_SERVER_ERROR);
	}
	
	
	private Users configUser(Map<String, String>map) {
		
		try {
			DateTimeFormatter dtf = DateTimeFormatter.ofPattern("yyyy/MM/dd HH:mm:ss");  
			   LocalDateTime now = LocalDateTime.now();  
			
			Users user = new Users();
			
			user.setName(map.get("name"));
			user.setUsername(map.get("username"));
			user.setAddress(map.get("address"));
			user.setPassword(map.get("password"));
	        String gender = map.get("gender");
			return user;
		} catch (Exception e) {
			e.printStackTrace();
		}
		return null;
		
	}
}
