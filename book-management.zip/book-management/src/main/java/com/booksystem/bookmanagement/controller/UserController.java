package com.booksystem.bookmanagement.controller;

import org.springframework.beans.factory.annotation.Autowired;

import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;

import com.booksystem.bookmanagement.dao.UserDao;
import com.booksystem.bookmanagement.pojo.Users;


@RequestMapping("/user")
public class UserController {

    @Autowired
    private UserDao userDao;

    @PostMapping("/add")
    public String addUser(@RequestBody Users users) {
    	userDao.save(users);
        return "User added successfully!";
    }
}

